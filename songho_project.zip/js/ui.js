// UI Songho générée
console.log('Songho UI');